# modified-datasets-for-remote-sensing-image-caption

## Introduction

These json files are mainly used for remote sensing image caption. And these files are just the sentence labels of images. The orginal datasets and images are available at https://github.com/201528014227051/RSICD_optimal. The contribution of the original datasets is huge, but there are many errors which are difficult to apply in practice. Therefore, we have made a lot of revisions to the data sets. The number of sentences we have modified for the three datasets Sydney, UCM and RSICD are 160, 374 and 7166 respectively.


## References

Thanks to https://github.com/201528014227051/RSICD_optimal<br/>


